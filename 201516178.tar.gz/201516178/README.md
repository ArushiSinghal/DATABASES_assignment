# SQL_search_engine
A mini SQL engine for database queries implemented in python which will run a subset of SQL Queries using command line interface.
