#!/bin/bash
sudo apt-get update
sudo apt-get upgrade
sudo apt-get install
sudo apt-get install vim
sudo apt-get install python-pip python3-pip
sudo pip3 install -U numpy
sudo pip install -U numpy
sudo pip3 install --upgrade sqlparse
sudo pip install matplotlib
sudo apt-get install python-tk
sudo pip install --upgrade sqlparse
python sql.py
